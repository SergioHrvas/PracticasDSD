Para esta práctica he arreglado la reutilización de estilos compartidos de CSS.

Además, como extra he implementado las siguientes funcionalidades con JS:
- Animación al mostrar comentarios
- Animación al insertar comentario
- Modo nocturno / Modo normal (bombilla superior derecha)
- Actualización de caracteres restantes en el comentario en tiempo real
- Juego de oferta aleatorio entre una lista definida en JavaScript